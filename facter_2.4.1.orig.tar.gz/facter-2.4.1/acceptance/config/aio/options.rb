{
  :type => 'aio',
  :pre_suite => [
    'setup/common/00_EnvSetup.rb',
    'setup/aio/pre-suite/010_Install.rb',
  ],
}
